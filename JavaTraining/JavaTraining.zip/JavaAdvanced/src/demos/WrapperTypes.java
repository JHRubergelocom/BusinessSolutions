package demos;

public class WrapperTypes {
    public static void main(String[] args) {
        Integer i = 5;
        int b = Integer.valueOf(10);
        System.out.println(b);
    }
}
