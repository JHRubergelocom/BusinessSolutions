package demos;

public class Primitives {
    public static void main(String[] args) {
        int a = 12;
        int b = (int)5L;
        long l1 = 30;
        int c = a / b;
        System.out.println(c);
        System.out.println(5_000_000_000L / 3);
        System.out.println(b);

        double d1 = 12.3;
        float f1 = 14.4F;
    }
}