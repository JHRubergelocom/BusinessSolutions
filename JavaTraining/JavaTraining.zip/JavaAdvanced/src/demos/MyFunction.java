package demos;

@FunctionalInterface
public interface MyFunction {
    Integer apply(CalculatorEngine calculatorEngine);
}
